﻿using Android.App;
using Android.OS;
using Android.Util;
//using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using Android.Support.V7.App;
using Android.Graphics;
using Android.Content;
using Newtonsoft.Json;

namespace project
{
    [Activity(Label = "@string/app_name")]
    public class MainActivity : AppCompatActivity
    {
        //Button btnSignIn, btnSignUp;
        //TextView txtSlogan;
        //protected override void OnCreate(Bundle bundle)
        //{
        //    base.OnCreate(bundle);

        //    SetContentView(Resource.Layout.activity_main);

        //    txtSlogan = FindViewById<EditText>(Resource.Id.txtSlogan);
        //    btnSignIn = FindViewById<Button>(Resource.Id.btnSignIn);
        //    btnSignUp = FindViewById<Button>(Resource.Id.btnSignUp);

        //    Typeface face = Typeface.CreateFromAsset(Application.Context.Assets, "fonts/Nabila.ttf");
        //    txtSlogan.SetTypeface(face, TypefaceStyle.Normal);

        //    btnSignIn.Click += BtnSignIn_Click;
        //    btnSignUp.Click += BtnSignUp_Click;

        //}

        //private void BtnSignIn_Click(object sender, System.EventArgs e)
        //{
        //    Intent signin = new Intent(this, typeof(SignIn));

        //    this.StartActivity(signin);

        //}

        //private void BtnSignUp_Click(object sender, System.EventArgs e)
        //{
        //    Intent signup = new Intent(this, typeof(SignUp));

        //    this.StartActivity(signup);

        //}
    }

}