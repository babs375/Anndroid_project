﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using project.Interface;

namespace project.ViewHolder
{
    class FoodViewHolder // : RecyclerView.ViewHolder , View.OnClickListener
    {

    //public TextView food_name;
    //public ImageView food_image;

    //private ItemClickListener itemClickListener;

    //public void setItemClickListener(ItemClickListener itemClickListener)
    //{
    //    this.itemClickListener = itemClickListener;
    //}

    //public FoodViewHolder(View itemView)
    //{
    //    super(itemView);

    //    food_name = (TextView)itemView.findViewById(R.id.food_name);
    //    food_image = (ImageView)itemView.findViewById(R.id.food_image);

    //    itemView.setOnClickListener(this);
    //}

    //@Override
    //public void onClick(View view)
    //{

    //    itemClickListener.onClick(view, getAdapterPosition(), false);

    //}
    }
}