﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using project.Interface;

namespace project.ViewHolder
{
    public class MenuViewHolder //: RecyclerView.ViewHolder , View.OnClickListener
    {

    //public TextView txtMenuName;
    //public ImageView imageView;

    //private ItemClickListener itemClickListener;

    //public MenuViewHolder(View itemView)
    //{
    //    super(itemView);

    //    txtMenuName = itemView.findViewById(R.id.menu_name);
    //    imageView = itemView.findViewById(R.id.menu_image);

    //    itemView.setOnClickListener(this);

    //}

    //public void setItemClickListener(ItemClickListener itemClickListener)
    //{
    //    this.itemClickListener = itemClickListener;
    //}

    //@Override
    //    public void onClick(View view)
    //{
    //    itemClickListener.onClick(view, getAdapterPosition(), false);
    //}
    }
}