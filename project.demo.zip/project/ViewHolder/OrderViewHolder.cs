﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using project.Interface;

namespace project.ViewHolder
{
    public class OrderViewHolder //: RecyclerView.ViewHolder
    {
        
    //    public TextView txtOrderId, txtOrderStatus, txtOrderphone, txtOrderAddress;

    //    private ItemClickListener itemClickListener;
        
        
    //    public OrderViewHolder(View itemview, Action<int> listener)
    //    {
    //        txtOrderAddress = itemview.FindViewById<TextView>(Resource.Id.order_address);
    //        txtOrderId = itemview.FindViewById<TextView>(Resource.Id.order_id);
    //        txtOrderStatus = itemview.FindViewById<TextView>(Resource.Id.order_status);
    //        txtOrderphone = itemview.FindViewById<TextView>(Resource.Id.order_phone);
    //        //itemview.Click += (sender, e) => listener(base.Position);
    //    }

    //    public void setItemClickListener(ItemClickListener itemClickListener)
    //    {
    //        this.itemClickListener = itemClickListener;
    //    }
    }
}